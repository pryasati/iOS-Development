//
//  ViewController.swift
//  Top CryptoCoins
//
//  Created by Poyan Ryasati on 3/10/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int
    {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return cryptoArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let crypto = cryptoArray[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "coins", for: indexPath)
        
        cell.textLabel?.text = crypto.abbreviation
        cell.detailTextLabel?.text = crypto.fullName
        cell.imageView?.image = crypto.icon
        
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        guard let detailViewController = segue.destination as? DetailViewController else { return }
        guard let cell = sender as? UITableViewCell else { return }
        guard let indexPath = self.tableView.indexPath(for: cell) else { return }
        detailViewController.coins = cryptoArray[indexPath.row]
    }
}

