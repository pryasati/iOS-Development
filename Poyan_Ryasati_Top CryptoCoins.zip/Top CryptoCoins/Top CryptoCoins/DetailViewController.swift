
//
//  DetailViewController.swift
//  Top CryptoCoins
//
//  Created by Poyan Ryasati on 3/10/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var mCapLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UITextView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var coinLogo: UIImageView!
    @IBOutlet weak var iconShadow: UIImageView!
    
    var coins : Cryptocurrency?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {

        nameLabel.text = coins?.fullName
        descriptionLabel.text = coins?.description
        mCapLabel.text = "MCap: \(coins!.marketCap)"
        coinLogo.image = UIImage(named: coins!.bigIcon.accessibilityIdentifier!)
        iconShadow.image = UIImage(named: "shadow.png")
      
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
