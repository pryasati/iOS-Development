//
//  CryptoCoins.swift
//  Top CryptoCoins
//
//  Created by Poyan Ryasati on 3/10/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import Foundation
import UIKit

//currently top 15 coins
let cryptoArray = [
    Cryptocurrency(UIImage(named: "big btc.png")!, UIImage(named: "btc.png")!, "BTC", "Bitcoin", "$69.27 B", "Bitcoin (BTC) is a consensus network that enables a new payment system and a completely digital currency. Powered by its users, it is a peer to peer payment network that requires no central authority to operate. On October 31st, 2008, an individual or group of individuals operating under the pseudonym Satoshi Nakamoto published the Bitcoin Whitepaper and described it as: a purely peer-to-peer version of electronic cash would allow online payments to be sent directly from one party to another without going through a financial institution."),
    
    Cryptocurrency(UIImage(named: "big eth.png")!, UIImage(named: "ethereum.png")!, "ETH", "Ethereum", "$14.29 B", "Ethereum (ETH) is a smart contract platform that enables developers to build decentralized applications (dapps) conceptualized by Vitalik Buterin in 2013. ETH is the native currency for the Ethereum platform and also works as the transaction fees to miners on the Ethereum network."),
    
    Cryptocurrency(UIImage(named: "big xrp.png")!, UIImage(named: "xrp.png")!, "XRP", "Ripple", "$13.00 B", "Ripple (XRP) is an independent digital asset that is native to the Ripple Consensus Ledger. With proven governance and the fastest transaction confirmation of its kind, XRP is said to be the most efficient settlement option for financial institutions and liquidity providers seeking global reach, accessibility and fast settlement finality for interbank flows."),
    
    Cryptocurrency(UIImage(named: "big ltc.png")!, UIImage(named: "ltc.png")!, "LTC", "Litecoin", "$3.45 B", "Litecoin is a peer-to-peer cryptocurrency created by Charlie Lee. It was created based on the Bitcoin protocol but differs in terms of the hashing algorithm used. Litecoin uses the memory intensive Scrypt proof of work mining algorithm. Scrypt allows consumer-grade hardware such as GPU to mine those coins."),
    
    Cryptocurrency(UIImage(named: "big eos.png")!, UIImage(named: "eos.png")!, "EOS", "EOS", "$3.37 B", "EOS.IO is a blockchain protocol powered by the native cryptocurrency EOS. The protocol emulates most of the attributes of a real computer including hardware (CPU(s) & GPU(s) for processing, local/RAM memory, hard-disk storage) with the computing resources distributed equally among EOS cryptocurrency holders. EOSIO operates as a smart contract platform and decentralized operating system intended for the deployment of industrial-scale decentralized applications through a decentralized autonomous corporation model. The smart contract platform claims to eliminate transaction fees and also conduct millions of transactions per second. EOS (EOS) is software that introduces a blockchain architecture designed to enable vertical and horizontal scaling of decentralized applications. The EOS software provides accounts, authentication, databases, asynchronous communication and the scheduling of applications across multiple CPU cores and/or clusters."),
    
    Cryptocurrency(UIImage(named: "big bch.png")!, UIImage(named: "bch.png")!, "BCH", "Bitcoin Cash", "$2.34 B", "Bitcoin Cash (BCH) is hard fork (a community-activated update to the protocol or code) of Bitcoin that took effect on August 1st, 2017 that increased the block size to 8MB, to help the scale the underlying technology of Bitcoin.Nov 16th 2018: BCH was hard forked again and split into Bitcoin SV and Bitcoin ABC. Bitcoin ABC became the dominant chain and took over the BCH ticker as it had more hashpower and majority of the nodes in the network."),
    
    Cryptocurrency(UIImage(named: "big usdt.png")!, UIImage(named: "usdt.png")!, "USDT", "Tether", "$2.01 B", "Tether (USDT) is a cryptocurrency with a value meant to mirror the value of the U.S. dollar. The idea was to create a stable cryptocurrency that can be used like digital dollars. Coins that serve this purpose of being a stable dollar substitute are called “stable coins.” According to their site, Tether converts cash into digital currency, to anchor or “tether” the value of the coin to the price of national currencies like the US dollar, the Euro, and the Yen."),
    
    Cryptocurrency(UIImage(named: "big bnb.png")!, UIImage(named: "bnb.svg")!, "BNB", "Binance Coin", "$2.01 B", "Binance Coin (BNB) is the cryptocurrency of the Binance platform. The name Binance is a combination of binary and finance. As of 2019, many businesses accept BNB as a form of payment."),
    
    Cryptocurrency(UIImage(named: "big xlm.png")!, UIImage(named: "xlm.png")!, "XLM", "Stellar", "$1.89 B", "The Stellar network is an open source, distributed, and community owned network used to facilitate cross-asset transfers of value. Stellar aims to help facilitate cross-asset transfer of value at a fraction of a penny while aiming to be an open financial system that gives people of all income levels access to low-cost financial services. Stellar can handle exchanges between fiat-based currencies and between cryptocurrencies. Stellar.org, the organization that supports Stellar, is centralized like XRP and meant to handle cross platform transactions and micro transactions like XRP."),
    
    Cryptocurrency(UIImage(named: "big trx.png")!, UIImage(named: "trx.png")!, "TRX", "Tron", "$1.52 B", "TRON (TRX) strives to build the future of a truly decentralized internet and global free content entertainment system that utilizes blockchain technology. The TRON Protocol represents the architecture of an operating system based on the blockchain which could enable developers to create smart contracts and decentralized applications, freely publish, own, and store data and other content. According to the TRON Foundation, the ecosystem surrounding this network specializes in offering massive scalability and consistent reliability capable of processing transactions at a high rate via high-throughput computing."),
    
    Cryptocurrency(UIImage(named: "big bsv.png")!, UIImage(named: "bsv.png")!, "BSV", "Bitcoin SV", "$1.17 B", "Bitcoin SV stands for Satoshi Vision. Stemming from Bitcoin Cash, BSV is a hard fork (community-activated update to the protocol or code) established as distinct from BCH after the network upgrade scheduled for November 15th, 2018 resulted in a hash war determining the chains would be split. According to their website, the Bitcoin SV project is primarily backed by CoinGeek Mining with development work by nChain."),
    
    Cryptocurrency(UIImage(named: "big ada.png")!, UIImage(named: "ada.png")!, "ADA", "Cardano", "$1.17 B", "Cardano (ADA) is a decentralized platform that will allow complex programmable transfers of value in a secure and scalable fashion. It is one of the first blockchains to be built in the Haskell programming language. Cardano is developing a smart contract platform which seeks to deliver more advanced features than any protocol previously developed. It is the first blockchain platform to evolve out of a scientific philosophy and a research-first driven approach. The development team consists of a large global collective of expert engineers and researchers. The protocol features a layered blockchain software stack that is flexible, scalable, and is being developed with the most rigorous academic and commercial software standards in the industry. Cardano will use a democratic governance system that allows the project to evolve over time, and fund itself sustainably through a visionary treasury system."),
    
    Cryptocurrency(UIImage(named: "big xmr.png")!, UIImage(named: "xmr.png")!, "XMR", "Monero", "$853.07 M", "Monero (XMR) is a private, secure, and untraceable cryptocurrency that was launched April 18th, 2014. With Monero, it is said you are in complete control of your funds and privacy no one else can see anyone else's balances or transactions."),
    
    Cryptocurrency(UIImage(named: "big iota.png")!, UIImage(named: "iota.png")!, "MIOTA", "IOTA", "$782.96 M", "IOTA (IOTA) is a distributed ledger for the Internet of Things that uses a directed acyclic graph (DAG) instead of a conventional blockchain. Its quantum-proof protocol, Tangle, reportedly brings benefits like 'zero fees, infinite scalability, fast transactions, and secure data transfer'. The IOTA Tangle is a Directed Acyclic Graph which has no fees on transactions and no fixed limit on how many transactions can be confirmed per second in the network; instead, the throughput grows in conjunction with activity in the network; i.e., the more activity, the faster the network."),
    
    Cryptocurrency(UIImage(named: "big dash.png")!, UIImage(named: "dash.png")!, "DASH", "DASH", "$720.76 M", "Dash (DASH), formerly known as Darkcoin until March 26th, 2015, is a privacy-centric digital currency with instant transactions. Similar to cash, Dash allows you to remain anonymous while transacting. Dash protects privacy by anonymizing transactions that are made over the network using a technology developed by the Dash team called DarkSend. DarkSend is inspired by the CoinJoin project that was birthed to anonymize Bitcoin transactions."),
]

class Cryptocurrency
{

    var abbreviation : String
    var fullName : String
    var marketCap : String
    var description : String
    let icon : UIImage
    let bigIcon : UIImage
    //let icon : UIImage
    

    init(_ bigIcon : UIImage, _ icon : UIImage, _ abbreviation : String, _ fullName : String, _ marketCap : String, _ description : String) {
        
        self.abbreviation = abbreviation
        self.icon = icon
        self.bigIcon = bigIcon
        self.fullName = fullName
        self.marketCap = marketCap
        self.description = description
    }
}
