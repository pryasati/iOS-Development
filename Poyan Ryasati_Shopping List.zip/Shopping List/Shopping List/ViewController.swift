//
//  ViewController.swift
//  Shopping List
//
//  Created by Poyan Ryasati on 2/15/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var itemName: UITextField!
    @IBOutlet weak var itemQuntity: UITextField!
    @IBOutlet weak var shoppingList: UITextView!
    
    var itemArray : [String] = []
    var itemQty : [Int] = []
    var goodEntry : Bool = false
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //setting default keyboards and formatting
        itemName.keyboardType = UIKeyboardType.alphabet
        itemQuntity.keyboardType = UIKeyboardType.numberPad
        itemName.autocapitalizationType = .sentences
        
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //initializing upon new list button press
    @IBAction func newListButton(_ sender: UIButton)
    {
        itemArray.removeAll()
        itemQty.removeAll()
        shoppingList.text = "No Item"
        itemName.text = ""
        itemQuntity.text = ""
    }
    
    //clrearing fields for new item entry
    @IBAction func newItemButton(_ sender: UIButton)
    {
        itemName.text = ""
        itemQuntity.text = ""
    }
    
    //this function checks to see if all conditions of a valid input are met
    //if so, it will set 'goodEntry' to true and adds the valid antry to the array
    //to be displayed in view.
    @IBAction func addItemButton(_ sender: UIButton)
    {
        //containsOnlyLetters(input: itemName.text!)
        if (itemQuntity.text == "" && itemName.text == "")
        {
            //Messages notifying user to put valid entries. ie not empty fields
            let title = "Alert!"
            let alertController = UIAlertController(title: title, message: "Please fill empty fields.", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            present(alertController, animated: true, completion: nil)
        }
        else if (itemQuntity.text == "")
        {
            let title = "Alert!"
            let alertController = UIAlertController(title: title, message: "Quantity field is empty.", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            present(alertController, animated: true, completion: nil)
        }
        else if (itemName.text == "")
        {
            let title = "Alert!"
            let alertController = UIAlertController(title: title, message: "Description field is empty.", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            present(alertController, animated: true, completion: nil)
        }
        else
        {
            for chr in itemName.text!
            {
                if (!(chr >= "a" && chr <= "z") && !(chr >= "A" && chr <= "Z") )
                {
                    itemName.text = ""
                    goodEntry = false
                    let title = "Invalid Input!"
                    let message = "Please enter char type into the Description field (A-Z, a-z)"
                    let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
                    
                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(cancelAction)
                    present(alertController, animated: true, completion: nil)
                }
                else {goodEntry = true}
            }
            if (goodEntry == true)
            {
                shoppingList.text = "Qty       Name\n===============\n"
                itemArray.append(itemName.text!)
                
                if let qty = itemQuntity.text
                {
                    itemQty.append(Int(qty) ?? 0)
                }
                
                for i in 0 ..< itemArray.count
                {
                    shoppingList.text = shoppingList.text.appending("\(itemQty[i])x        \(itemArray[i])\n")
                }
            }
        }
    }
    
    //to dismis keyboards
    @IBAction func dismisDescription(_ sender: UITextField)
    {
        sender.resignFirstResponder()
    }
    
    @IBAction func dismisQty(_ sender: UIControl)
    {
        itemQuntity.resignFirstResponder()
    }
}
