//
//  ViewController.swift
//  PR_Assignment1
//
//  Created by Poyan Ryasati on 1/9/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var label: UILabel!
    var name:String = ""
    @IBOutlet weak var label2: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        label2.isHidden = true

        label.text = "Hello World!"
        
        
        
    }

    @IBAction func submitButton(_ sender: Any) {
        label2.isHidden = false
        name = textField.text!
        label2.text = "Hi \(name)!"
        textField.resignFirstResponder()
    }
}

