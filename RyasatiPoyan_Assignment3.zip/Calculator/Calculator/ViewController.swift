//
//  ViewController.swift
//  Calculator
//
//  Created by Poyan Ryasati on 1/31/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var label: UILabel!
    
    
    var labelString: Int = 0
    var lastVal: Int = 0
    var result: Int = 0
    var operationButtonPressed: Bool = false
    var equalButtonPressed: Bool = false
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //label.text = ""
    }
    
    
    @IBAction func buttonPressed(_ sender: UIButton)
    {
        //To reset operatipn and have user input second value
        if (operationButtonPressed == true)
        {
            label.text = ""
            label.text = label.text?.appending(sender.currentTitle!)
            operationButtonPressed = false
        }
            
            //Initial input to record first value before any operation button has been pressed
        else if let title = sender.currentTitle
        {
            label.text = label.text?.appending("\(title)")
        }
        
        //For personal debugging purposes. Can ignore.
        //print("\(label.text!) , \(operationButtonPressed), \(lastVal), \(result)")
    }
    
    //Final operation to add and record result and output to lable
    @IBAction func pressedEqual(_ sender: Any)
    {
        operationButtonPressed = true
        result = Int(label.text!)! + lastVal
        label.text = "\(result)"
    }
    
    //To set boolean to true and record last entered num
    @IBAction func pressedAdd(_ sender: Any)
    {
        operationButtonPressed = true
        lastVal = Int(label.text!)!
    }
    
    //Will clear value
    @IBAction func pressedClear(_ sender: Any)
    {
        label.text = "0"
    }
    
}



