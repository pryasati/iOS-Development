//
//  MyDvrViewController.swift
//  TVRemote
//
//  Created by Poyan Ryasati on 2/23/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

class MyDVRViewController: UIViewController
{

    @IBOutlet weak var powerOffLabel: UILabel!
    @IBOutlet weak var stateOfDVR: UILabel!
    @IBOutlet var remoteButtons: [UIButton]!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        powerOffLabel.text = "OFF"
        powerOffLabel.textColor = UIColor.red
        //disable buttons on viewDidLoad
        for i in remoteButtons.startIndex ..< remoteButtons.endIndex
        {
            remoteButtons[i].isEnabled = false
        }
        // Do any additional setup after loading the view.
    }
    //seque transition
    @IBAction func switchToTv(_ sender: UIButton)
    {
        dismiss(animated: true, completion: nil)
    }
    //power button logic to initialize and set values
    @IBAction func powerButton(_ sender: UISwitch)
    {
        
        if (sender.isOn == true)
        {
            stateOfDVR.text = "STOPPED"
            powerOffLabel.text = "ON"
            powerOffLabel.textColor = UIColor.green
            for i in remoteButtons.startIndex ..< remoteButtons.endIndex
            {
                remoteButtons[i].isEnabled = true
            }
        }
        
        if (sender.isOn == false)
        {
            stateOfDVR.text = ""
            powerOffLabel.text = "OFF"
            powerOffLabel.textColor = UIColor.red
            for i in remoteButtons.startIndex ..< remoteButtons.endIndex
            {
                remoteButtons[i].isEnabled = false
            }
        }
    }
    //the next few functions are Actions for the buttons to set the current state and call the function that
    //is reponsible for forcing a prohibited state to start.
    @IBAction func playButton(_ sender: UIButton)
    {

        if (stateOfDVR.text != "RECORDING")
        {
            stateOfDVR.text = "PLAYING"
        }
        else
        {
            forceOperationAlerts("Force Play",
                                 "PLAYING",
                                 "Cannot Play while recording. Would you like to force this action?")
        }
    }
    
    @IBAction func pauseButton(_ sender: UIButton)
    {
        if (stateOfDVR.text == "PLAYING")
        {
            stateOfDVR.text = "PAUSED"
        }
        else
        {
            forceOperationAlerts("Force Pause",
                                 "PAUSED",
                                 "Cannot Pause during current operation. Would you like to force this action?")
        }
    }
    
    @IBAction func stopButton(_ sender: UIButton)
    {
        stateOfDVR.text = "STOPPED"
    }
    
    @IBAction func recordButton(_ sender: UIButton)
    {
        if (stateOfDVR.text == "STOPPED")
        {
            stateOfDVR.text = "RECORDING"
        }
        else
        {
            forceOperationAlerts("Force Record",
                                 "RECORDING",
                                 "Cannot Record during current operation. Would you like to force this action?")
        }
    }
    
    @IBAction func fForwardButton(_ sender: UIButton)
    {
        if (stateOfDVR.text == "PLAYING")
        {
            stateOfDVR.text = "FAST FORWARDING"
        }
        else
        {
            forceOperationAlerts("Force Fast Forward",
                                 "FAST FORWARDING",
                                 "Cannot Fast Forward during current operation. Would you like to force this action?")
        }
    }
    
    @IBAction func fBackwardButton(_ sender: UIButton)
    {
        if (stateOfDVR.text == "PLAYING")
        {
            stateOfDVR.text = "REWINDING"
        }
        else
        {
            forceOperationAlerts("Force Rewind",
                                 "REWINDING",
                                 "Cannot Rewind during current operation. Would you like to force this action?")
        }
    }
    //to prompt the user with an alert or action sheet to notify when
    //user attempts to force a state that is not allowed
    func forceOperationAlerts(_ title : String, _ forcedState : String, _ message : String)
    {
        let forcePause = UIAlertAction(title: title,
                                       style: .default) { _ in
            self.stateOfDVR.text = forcedState
            let alertController = UIAlertController(title: "Previous operation was stopped!",
                                                    message: "Requsted operation proceeds.",
                                                    preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK",
                                         style: .cancel,
                                         handler: nil)
            alertController.addAction(okAction)
            self.present(alertController,
                         animated: true,
                         completion: nil)
        }
        
        let cancel = UIAlertAction(title: "Cancel" , style: .destructive, handler: nil)
        let actionSheetController =
            UIAlertController(title: "ALERT!",
                              message: message,
                              preferredStyle: .actionSheet)
        
        actionSheetController.addAction(forcePause)
        actionSheetController.addAction(cancel)
        present(actionSheetController,
                animated: true,
                completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
