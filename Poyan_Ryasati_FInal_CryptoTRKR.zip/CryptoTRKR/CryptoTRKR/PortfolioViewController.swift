//
//  ViewController.swift
//  CryptoTRKR
//
//  Created by Poyan Ryasati on 3/15/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

class PortfolioViewController: UIViewController {

    @IBOutlet weak var exchangeNameField: UITextField!
    @IBOutlet weak var currencyField: UITextField!
    @IBOutlet weak var amountField: UITextField!
    @IBOutlet weak var pricePurchasedAtField: UITextField!
    @IBOutlet weak var listOfAddedCurrencies: UITextView!
    @IBOutlet weak var portfolioValue: UILabel!
    
    
    var exchangeNameArray : [String] = []
    var currencyNameArray : [String] = []
    var qtyArray : [Int] = []
    var priceArray : [Int] = []
    var goodEntry : Bool = false
    var newPortfolioVal : Int = 0
    
    @objc func handleShowIndexPath()
    {
        print("Reloading")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        exchangeNameField.keyboardType = UIKeyboardType.alphabet
        currencyField.keyboardType = UIKeyboardType.alphabet
        amountField.keyboardType = UIKeyboardType.numberPad
        pricePurchasedAtField.keyboardType = UIKeyboardType.numbersAndPunctuation
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "REFRESH", style: .done, target: self, action: #selector(handleShowIndexPath))
    }

    
    
    
    
    @IBAction func addButton(_ sender: UIButton) {
        
        if (exchangeNameField.text == "" || currencyField.text == "" || amountField.text == "" || pricePurchasedAtField.text == "")
        {
            //Messages notifying user to put valid entries. ie not empty fields
            let title = "Alert!"
            let alertController = UIAlertController(title: title, message: "Please fill empty fields.", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            present(alertController, animated: true, completion: nil)
        }
        else
        {
            goodEntry = true
            if (goodEntry == true)
            {
                listOfAddedCurrencies.text = ""
                exchangeNameArray.append(exchangeNameField.text!)
                currencyNameArray.append(currencyField.text!)
                priceArray.append(Int(pricePurchasedAtField.text!) ?? 0)
                
                let priceToInt = Int(pricePurchasedAtField.text ?? "Err")
                let qtyTOInt = Int(amountField.text ?? "Err")
                
                newPortfolioVal += portfolioValuation(priceToInt ?? 0, qtyTOInt ?? 0)
                portfolioValue.text = "$\(String(newPortfolioVal))"
                
                if let qty = amountField.text
                {
                    qtyArray.append(Int(qty) ?? 0)
                }
                
                for i in 0 ..< currencyNameArray.count
                {
                    listOfAddedCurrencies.text = listOfAddedCurrencies.text.appending("\(exchangeNameArray[i])                             \(currencyNameArray[i])                       \(qtyArray[i])                     \(priceArray[i])\n")
                }
            }
            
            
        }
    }
    
    @IBAction func cancelButton(_ sender: UIButton) {
        exchangeNameField.text = ""
        currencyField.text = ""
        pricePurchasedAtField.text = ""
        amountField.text = ""
    }
    
    @IBAction func DismisExchangeButton(_ sender: UITextField) {
        sender.resignFirstResponder()
    }

    @IBAction func dimisCurrencyField(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    
    
    @IBAction func dismisPriceField(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    
    @IBAction func dismisFields(_ sender: UIControl)
    {
        amountField.resignFirstResponder()
        pricePurchasedAtField.resignFirstResponder()
        currencyField.resignFirstResponder()
        exchangeNameField.resignFirstResponder()
    }
    
    func portfolioValuation (_ price : Int, _ qty : Int) -> Int
    {
        var newP = 0
        if qty < 1 {
            listOfAddedCurrencies.text.append("QTY MUST BE > 1")
        }
        else{
        newP = price * qty
        }
        
        return newP
    }
    
    
    @IBAction func BinanceExternalLinkSignUp(_ sender: UIButton) {
        
        guard let url = URL(string: "https://www.binance.com/m-register.html?ref=11681555") else { return }
        UIApplication.shared.open(url)
    }
    

}

