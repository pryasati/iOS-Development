//
//  favCoinsTableViewCell.swift
//  CryptoTRKR
//
//  Created by Poyan Ryasati on 3/18/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

class favCoinsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var favRankLabel: UILabel!
    @IBOutlet weak var favNameLabel: UILabel!
    @IBOutlet weak var favSymbolLabel: UILabel!
    @IBOutlet weak var favChangeLabel: UILabel!
    @IBOutlet weak var favePriceLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}


