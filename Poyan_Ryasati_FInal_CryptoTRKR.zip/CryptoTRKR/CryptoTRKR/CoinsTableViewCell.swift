//
//  CoinsTableViewCell.swift
//  CryptoTRKR
//
//  Created by Poyan Ryasati on 3/16/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

var isFavorited : Bool = false


class CoinsTableViewCell: UITableViewCell {

    @IBOutlet weak var rankLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var symbolLabel: UILabel!
    @IBOutlet weak var changeLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    
    
//    @IBAction func setAttendance(_ sender: Any){
//        // Get cell index
//        let indexPath :NSIndexPath = (self.superview! as! UITableView).indexPath(for: self)! as NSIndexPath
//
//        if !addButton.isSelected{
//            Utility.Instance.checkedCells.append(indexPath.row)
//        }else{
//            // remove unchecked cell from list
//            if let index = Utility.Instance.checkedCells.index(of: indexPath.row){
//                Utility.Instance.checkedCells.remove(at: index)
//            }
//        }
//        // toggle state
//        addButton.isSelected = !addButton.isSelected
//    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //favIconIV.tintColor = .gray
        //favIconIV.tintColor = .gray
        
    }
    
//    @IBAction func favButton(_ sender: UIButton)
//    {
//        favIconIV.tintColor = .yellow
//        isFavorited = true
//        addFavB.isEnabled = false
//        removeFavB.isEnabled = true
//    }
//
//    @IBAction func removeFavButtonn(_ sender: UIButton)
//    {
//        isFavorited = false
//        favIconIV.tintColor = .gray
//        addFavB.isEnabled = true
//        removeFavB.isEnabled = false
//    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        

        // Configure the view for the selected state
        //print("cell selected")
    }
}
