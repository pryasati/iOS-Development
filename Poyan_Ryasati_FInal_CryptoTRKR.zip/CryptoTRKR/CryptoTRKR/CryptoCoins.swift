//
//  CryptoCoins.swift
//  CryptoTRKR
//
//  Created by Poyan Ryasati on 3/16/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//


import Foundation


struct CoinMarket : Hashable {
    let name : String
    let symbol : String
    let rank : String
    let price_usd : String
    let percent_change_24h : String
    
    
    enum SerializationError: Error {
        case missing(String)
        case invalid(String, Any)
    }
    
    
    init(json:[String:Any]) throws {
        guard let name = json["name"] as? String else { throw SerializationError.missing("name is missing")}
        
        guard let symbol = json["symbol"] as? String else { throw SerializationError.missing("name is missing")}
        
        guard let rank = json["rank"] as? String  else { throw SerializationError.missing("rank is missing")}
        
        guard let price_usd = json["price_usd"] as? String  else { throw SerializationError.missing("rank is missing")}
        
        guard let percent_change_24h = json["percent_change_24h"] as? String  else { throw SerializationError.missing("rank is missing")}
        
        self.name = name
        self.symbol = symbol
        self.rank = rank
        self.price_usd = price_usd
        self.percent_change_24h = percent_change_24h
    }
    
    //coinmarketcap.com API
    static let basePath = "https://api.coinmarketcap.com/v1/ticker/"
    
    static func getCoinCapJSONData(completion: @escaping ([CoinMarket]?) -> ()) {
        
        let url = basePath
        let request = URLRequest(url: URL(string: url)!)
        
        let task = URLSession.shared.dataTask(with: request) { (data:Data?, response:URLResponse?, error:Error?) in
            
            var coinMarketArray:[CoinMarket] = []
            
            do {
                
                if let data = data {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [[String:Any]] {
                        
                        for coinData in json {
                            if let singleCoin = try? CoinMarket(json: coinData) {
                                coinMarketArray.append(singleCoin)
                                
                                //print(singleCoin)
                            }
                        }
                        
                    }
                    
                    
                }
                
                
            } catch {
                
                // catch internet connection failure
                
                
                print(error.localizedDescription)
            }
            completion(coinMarketArray)
            
            
            
            
        }
        task.resume()
    }
    
}
