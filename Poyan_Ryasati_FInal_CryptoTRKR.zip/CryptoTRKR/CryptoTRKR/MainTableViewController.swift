//
//  MainTableViewController.swift
//  CryptoTRKR
//
//  Created by Poyan Ryasati on 3/15/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

var favCoinsCollection = [CoinMarket]()
var globalPrice : Double?

class MainTableViewController: UITableViewController {
    
    var cryptoCoinArray = [CoinMarket]()
    var newPrice : Double?
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getCryptoCoinJSON()
        

    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.reloadData()
        getCryptoCoinJSON()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getCryptoCoinJSON() {
        CoinMarket.getCoinCapJSONData { (results:[CoinMarket]?) in
            if let coinMarketData = results {
                self.cryptoCoinArray = coinMarketData
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
            else{
                print("Falied to fetch coins data#######")
            }
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        // #warning Incomplete implementation, return the number of rows
        
        return cryptoCoinArray.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let crypto = cryptoCoinArray[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CoinsTableViewCell
        
        
        //globalPrice = Int(crypto.price_usd) ?? 1
        
        newPrice = Double(crypto.price_usd)
        globalPrice = ((newPrice ?? 0)*100).rounded()/100
        
        cell.nameLabel.text = crypto.name
        cell.rankLabel .text = crypto.rank
        cell.symbolLabel.text = crypto.symbol
        cell.changeLabel.text = "\(crypto.percent_change_24h)%"
        cell.priceLabel.text = "$\(String(globalPrice ?? 0))"

        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        favCoinsCollection.append(cryptoCoinArray[indexPath.row])
    }
    
    override func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

