//
//  Utility.swift
//  CryptoTRKR
//
//  Created by Poyan Ryasati on 3/18/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import Foundation



class Utility {
    
    var checkedCells = [Int]()
    // Singleton
    private static let _instance = Utility()
    static var Instance: Utility{
        return _instance
    }
    
    
}
