//
//  TVConfigViewController.swift
//  TVRemote
//
//  Created by Poyan Ryasati on 3/4/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

//setting segment names to Not Available and fav chan to to default 01 until user configres it
var newSegName1 : String = "N/A"
var newSegName2 : String = "N/A"
var newSegName3 : String = "N/A"
var newSegName4 : String = "N/A"
var configuredFavChan1 : String = "01"
var configuredFavChan2 : String = "01"
var configuredFavChan3 : String = "01"
var configuredFavChan4 : String = "01"

class TVConfigViewController: UIViewController
{
    
    @IBOutlet weak var segFavChannel: UISegmentedControl!
    @IBOutlet weak var newSegNameInput: UITextField!
    @IBOutlet weak var stepper: UIStepper!
    @IBOutlet weak var newChanLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func cancelButton(_ sender: UIButton)
    {
        //Was not sure what exactly needs to be in here since in the
        //instructions it says "the Cancel button will ignore the current
        //values, and the configuration of the favorite buttons will
        //remain unchanged. I will just empty the newSegNameInput field."
        newSegNameInput.text = ""
        newSegNameInput.resignFirstResponder()
    }
    
    //this is where everything gets executed.
    //first we check for any constraints
    //if not contraints, we execute and save cnfig by calling configureSegment()
    //and send the values to the golabal variables, which then are picked up by the TV view controller.
    @IBAction func saveButton(_ sender: UIButton)
    {
        if newSegNameInput.text!.count > 4 {
            print("too high")
            constraintAlert("Too High", "Lenght of segment name can not exceed 4 letters!")
        }
        else if newSegNameInput.text!.count < 1 {
            print("too low")
            constraintAlert("Too Low", "Segment name must atleast have one letter!")
        }
        else
        {
            newSegNameInput.resignFirstResponder()
            configurateSegments()
        }
    }
    
    //assigns the value of to selected segment. implemented using a switch statement
    func configurateSegments()
    {
        switch segFavChannel.selectedSegmentIndex {
        case 0:
            newSegName1 = newSegNameInput.text!
            configuredFavChan1 = newChanLabel.text!
        case 1:
            newSegName2 = newSegNameInput.text!
            configuredFavChan2 = newChanLabel.text!
        case 2:
            newSegName3 = newSegNameInput.text!
            configuredFavChan3 = newChanLabel.text!
        case 3:
            newSegName4 = newSegNameInput.text!
            configuredFavChan4 = newChanLabel.text!
        default:
            newSegName1 = ""
        }
        
    }
    
    //increment or decrement channel val
    @IBAction func chanValStepperButton(_ sender: UIStepper)
    {
        newChanLabel.text = String(Int(sender.value))
    }
    
    //dismis keyboard
    @IBAction func dismisKeyboard(_ sender: UITextField)
    {
        sender.resignFirstResponder()
    }
    
    //Pops up a alert message if input it too low or too high
    func constraintAlert(_ alertTitle : String, _ alertMessage : String)
    {
        let alert = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: .alert)

        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
}
