//
//  ViewController.swift
//  TVRemote
//
//  Created by Poyan Ryasati on 2/8/19.
//  Copyright © 2019 Poyan Ryasati. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    //public var globalUserInputforSegControlTitle : String = ""
    @IBOutlet weak var powerLabel: UILabel!
    @IBOutlet weak var chanLabel: UILabel!
    @IBOutlet weak var volumeLabel: UILabel!

    @IBOutlet weak var favSegmentedControl: UISegmentedControl!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var one: UIButton!
//    adding channel buttons to array to disable/enable later with PWR switch
    @IBOutlet var b: [UIButton]!
    

    var chanVal : String = ""
    var chanArray = [String]()
    var currentChannel : String = ""
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        powerLabel.textColor = UIColor.red
        powerLabel.text = "OFF"
        slider.isEnabled = false
        
//disabling chan buttons when view is loaded
        for i in b.startIndex ..< b.endIndex
        {
            b[i].isEnabled = false
        }
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        favSegmentedControl.setTitle(newSegName1, forSegmentAt: 0)
        favSegmentedControl.setTitle(newSegName2, forSegmentAt: 1)
        favSegmentedControl.setTitle(newSegName3, forSegmentAt: 2)
        favSegmentedControl.setTitle(newSegName4, forSegmentAt: 3)
    }
//function to take in and output current channel
    @IBAction func channels(_ sender: UIButton)
    {
        if let channels = sender.currentTitle
        {
            chanVal = "\(channels)"
        }
        
        if (chanArray.count == 0 || chanArray.count == 1)
        {
            chanArray.append(chanVal)
        }
        if (chanArray.count == 2)
        {
            currentChannel = chanArray[0] + chanArray[1]
            if (currentChannel == "00")
            {
                chanArray.removeAll()
            }
            else
            {
            chanLabel.text = currentChannel
            chanArray.removeAll()
            }
        }
    }
//function to control vol
    @IBAction func volControl(_ sender: UISlider)
    {
        volumeLabel.text = ("SPEAKER VOL: \(Int(sender.value))")
    }
//function for pwr button and to disable/enable buttons
    @IBAction func powerSwirch(_ sender: UISwitch)
    {
        if (sender.isOn == true)
        {
            powerLabel.text = ("ON")
            powerLabel.textColor = UIColor.green
            slider.isEnabled = true
            favSegmentedControl.isEnabled = true
            for i in b.startIndex ..< b.endIndex
            {
                b[i].isEnabled = true
            }
        }
        else
        {
            powerLabel.text = ("OFF")
            powerLabel.textColor = UIColor.red
            slider.isEnabled = false
            favSegmentedControl.isEnabled = false
            for i in b.startIndex ..< b.endIndex
            {
                b[i].isEnabled = false
            }
        }
    }

    @IBAction func channelDown(_ sender: UIButton)
    {
        let oldCh = Int(chanLabel.text!)
        
        if (oldCh == 1) {
            //do nothing and stay in bound
        }
        else
        {
            let newCh = oldCh! - 1
            chanLabel.text = "\(newCh)"
        }
        
        if (oldCh! < 11 && oldCh != 1)
        {
            let newCh = oldCh! - 1
            chanLabel.text = "0\(newCh)"
        }
    }
    
    @IBAction func channelUp(_ sender: UIButton)
    {
        let oldCh = Int(chanLabel.text!)
        
        if (oldCh == 99) {
            //do nothing and stay in bound
        }
        else
        {
            let newCh = oldCh! + 1
            chanLabel.text = "\(newCh)"
        }
        
        if (oldCh! < 9)
        {
            let newCh = oldCh! + 1
            chanLabel.text = "0\(newCh)"
        }
    }
    
//function to hardcode fav channels
    @IBAction func favChannel(_ sender: UISegmentedControl)
    {
        
        switch sender.selectedSegmentIndex
        {
        case 0:
            chanLabel.text = configuredFavChan1
        case 1:
            chanLabel.text = configuredFavChan2
        case 2:
            chanLabel.text = configuredFavChan3
        case 3:
            chanLabel.text = configuredFavChan4
        default:
            break
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

