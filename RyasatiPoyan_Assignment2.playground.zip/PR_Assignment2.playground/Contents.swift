import UIKit

// ### Part 1. Creating bianry search to find the index of a searched int
func rankBinarySearch(_ array : [Int], _ key : Int) -> Int
{
    var a = array //array to hold the array passed in to function
    a.sort() // sroting the given array
    var l = 0 // setting the low to the fist index
    var n = a.count - 1 //setting high to the size of the array
    
    while l <= n //while loop to iterate until l meets n
    {
        let mid = l + (n - l) / 2 //finding the middle of array
        
        if key < a[mid] //if key is in the left of mid, cut array and keep left split
        {
            n = mid - 1
        }
        else if key > a[mid] //if key is in the right of mid, cut array and keep right split
        {
            l = mid + 1
        }
        else // end of search, return key
        {
            print("Key Found: \(mid)")
            return mid
        }
    }
    return -1 // returning -1 if no key was found
}

rankBinarySearch([89,77,34,12,25,44,78,2,19,25,100,888], 89) //executing the function


// ### Part 2. Adding methods to the Fraction class
//This is typed by me from scratch based on the code you gave us and not copied and pasted. I have completed
//the class Fraction by adding the rest of functions as instructed in the directions.
class fractionOperation
{
    //initializing and setting the rule of a fraction
    var numerator: Int = 0
    var denominator: Int = 1
    
    //init aka constructor
    init(_ numerator: Int, over denominator: Int)
    {
        self.numerator = numerator
        self.denominator = denominator
    }
    
    //init() {}
    //This function is not really necessary here.
    func setTo(numerator: Int, over denominator: Int)
    {
        self.numerator = numerator
        self.denominator = denominator
    }
    
    func print()
    {
        Swift.print("\(numerator)/\(denominator)")
    }
    
    //converting to a Double
    func toDouble() -> Double
    {
        return Double(numerator) / Double(denominator);
    }
    
    //Adding two fractions
    func add(_ f: fractionOperation)
    {
        numerator = numerator * f.denominator + denominator * f.numerator
        denominator = denominator * f.denominator
        reduce()
    }
    
    //subtracting two fractions
    func subtract(_ f : fractionOperation)
    {
        numerator = numerator * f.denominator - denominator * f.numerator
        denominator = denominator * f.denominator
        reduce()
    }
    
    //multiplying two fractions
    func multiply(_ f : fractionOperation)
    {
        numerator = numerator * f.numerator
        denominator = denominator * f.denominator
        reduce()
    }
    
    //dividing two fractions
    func divide(_ f : fractionOperation)
    {
        numerator = numerator * f.denominator
        denominator = denominator * f.numerator
        reduce()
    }
    
    //reducing the fraction as the last step
    func reduce()
    {
        var u = abs(numerator)
        var v = denominator
        var r: Int
        while (v != 0)
        {
            r = u % v; u = v; v = r
        }
        numerator /= u
        denominator /= u
    }
    
}

//creating instances of the class
var f1 = fractionOperation(1, over: 2)
var f2 = fractionOperation(1, over: 4)

var f3 = fractionOperation(3, over: 6)
var f4 = fractionOperation(2, over: 9)

var f5 = fractionOperation(9, over: 18)
var f6 = fractionOperation(10, over: 9)

var f7 = fractionOperation(23, over: 14)
var f8 = fractionOperation(16, over: 7)

//calling the functions within the class
f1.add(f2)
f1.print()

f3.subtract(f4)
f3.print()

f5.multiply(f6)
f5.print()

f7.divide(f8)
f7.print()

